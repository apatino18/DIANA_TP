package io.testproject.addon;

import io.testproject.sdk.internal.addons.ActionProxy;
import io.testproject.sdk.internal.addons.ProxyDescriptor;
import java.lang.String;

/**
 * Proxy for Get random value from fixed list Addon */
public class Getrandomvaluefromfixedlist {
  /**
   * Factory method for RandomStringFromList */
  public static RandomStringFromList getRandomStringFromList() {
    return new RandomStringFromList();
  }

  /**
   * Factory method for RandomStringFromList
   * @param list Comma delimited list (Example: a,b,c,d) */
  public static RandomStringFromList randomStringFromList(String list) {
    return new RandomStringFromList(list);
  }

  /**
   * Get Random Value From Fixed List. Get random value from fixed list */
  public static class RandomStringFromList extends ActionProxy {
    /**
     * Comma delimited list (Example: a,b,c,d) (INPUT) */
    public String list;

    /**
     * Random string from list (OUTPUT) */
    public String randomResult;

    public RandomStringFromList() {
      this.setDescriptor(new ProxyDescriptor("uL4ptjq1h0O1oIdQkkqlyg", "RandomStringFromList"));
    }

    public RandomStringFromList(String list) {
      this();
      this.list = list;
    }
  }
}
