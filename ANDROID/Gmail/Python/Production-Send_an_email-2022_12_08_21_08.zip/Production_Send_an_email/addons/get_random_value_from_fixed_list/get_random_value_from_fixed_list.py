from .actions import RandomStringFromList


class GetRandomValueFromFixedList:
    @staticmethod
    def randomstringfromlist(list: str) -> RandomStringFromList:
        """Get random string from input list.

        Get random value from fixed list.
        """
        return RandomStringFromList(list)
