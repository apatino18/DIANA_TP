"""This package contains all the addon proxy's actions."""
from .randomstringfromlist import RandomStringFromList

__all__ = ["RandomStringFromList"]
