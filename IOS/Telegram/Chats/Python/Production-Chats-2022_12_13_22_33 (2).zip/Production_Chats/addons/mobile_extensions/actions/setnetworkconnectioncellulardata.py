"""This module contains the SetNetworkConnectionCellularData proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class SetNetworkConnectionCellularData(ActionProxy):
    def __init__(self, expectedState: str):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.android.SetNetworkConnectionCellularData"
        )
        self.expectedState = expectedState
