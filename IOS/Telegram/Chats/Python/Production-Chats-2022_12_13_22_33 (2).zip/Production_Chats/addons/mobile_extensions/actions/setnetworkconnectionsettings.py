"""This module contains the SetNetworkConnectionSettings proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class SetNetworkConnectionSettings(ActionProxy):
    def __init__(self, connectionSetting: str):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.android.SetNetworkConnectionSettings"
        )
        self.connectionSetting = connectionSetting
