"""This module contains the PushFile proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class PushFile(ActionProxy):
    def __init__(self, remotePath: str, localPath: str):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.android.PushFile"
        )
        self.remotePath = remotePath
        self.localPath = localPath
