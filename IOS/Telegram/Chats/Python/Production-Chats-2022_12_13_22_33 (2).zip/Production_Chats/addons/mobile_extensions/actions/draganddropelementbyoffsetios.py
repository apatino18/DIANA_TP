"""This module contains the DragAndDropElementByOffsetIOS proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class DragAndDropElementByOffsetIOS(ActionProxy):
    def __init__(self, xOffset: int, yOffset: int):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.ios.element.DragAndDropElementByOffsetIOS"
        )
        self.xOffset = xOffset
        self.yOffset = yOffset
