"""This module contains the HideKeyboardIOS proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class HideKeyboardIOS(ActionProxy):
    def __init__(self):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.ios.HideKeyboardIOS"
        )
