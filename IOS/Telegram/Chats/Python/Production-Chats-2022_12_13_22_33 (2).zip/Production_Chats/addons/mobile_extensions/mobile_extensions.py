from .actions import CheckIfScreenIsLocked, ClickKeyBoardSearch, DoubleTapOnElementAndroid, DragAndDropElementByOffsetAndroid, GetAttributeValue, GetElementSizeAndroid, PinchElementAndroid, SendKeysWithADB, ZoomToElementAndroid, FlickGestureAndroid, GetCurrentActivity, GetDeviceOrientationAndroid, GetNetworkConnectionCellularData, GetNetworkConnectionFlightMode, GetNetworkConnectionWiFiState, GetPackageName, HideKeyboardAndroid, InstallApp, IsAppInstalled, IsKeyboardVisible, OpenNotifications, PanGesturesAndroid, PullFile, PushFile, RemoveApp, SetAnimations, SetNetworkConnectionCellularData, SetNetworkConnectionFlightMode, SetNetworkConnectionSettings, SetNetworkConnectionWiFiState, SimulateFingerPrint, ToggleLocationServices, DoubleTapOnElementIOS, DragAndDropElementByOffsetIOS, GetElementSizeIOS, PinchElementIOS, ZoomToElementIOS, FlickGestureIOS, GetDeviceOrientationIOS, HideKeyboardIOS, PanGesturesIOS, Shake, SimulateTouchID, TypeTextKeyboardIOS


class MobileExtensions:
    @staticmethod
    def checkifscreenislocked() -> CheckIfScreenIsLocked:
        """Is screen locked?."""
        return CheckIfScreenIsLocked()

    @staticmethod
    def clickkeyboardsearch() -> ClickKeyBoardSearch:
        """Clicks the 'Search' button in Android keyboard."""
        return ClickKeyBoardSearch()

    @staticmethod
    def doubletaponelementandroid() -> DoubleTapOnElementAndroid:
        """Double tap on {{element}}."""
        return DoubleTapOnElementAndroid()

    @staticmethod
    def draganddropelementbyoffsetandroid(xOffset: int, yOffset: int) -> DragAndDropElementByOffsetAndroid:
        """Drag {{element}} by offset {{xOffset}},{{yOffset}} and drop."""
        return DragAndDropElementByOffsetAndroid(xOffset, yOffset)

    @staticmethod
    def getattributevalue(attribute: str) -> GetAttributeValue:
        """Returns android Element Attribute."""
        return GetAttributeValue(attribute)

    @staticmethod
    def getelementsizeandroid() -> GetElementSizeAndroid:
        """Get Element Size, Height and Width."""
        return GetElementSizeAndroid()

    @staticmethod
    def pinchelementandroid(scale: str) -> PinchElementAndroid:
        """Make a Pinch gesture on {{element}}."""
        return PinchElementAndroid(scale)

    @staticmethod
    def sendkeyswithadb(keys: str) -> SendKeysWithADB:
        """Type {{keys}} in {{element}}."""
        return SendKeysWithADB(keys)

    @staticmethod
    def zoomtoelementandroid(scale: str) -> ZoomToElementAndroid:
        """Make a Zoom gesture on {{element}}."""
        return ZoomToElementAndroid(scale)

    @staticmethod
    def flickgestureandroid(direction: str) -> FlickGestureAndroid:
        """Make a Flick gesture {{direction}}."""
        return FlickGestureAndroid(direction)

    @staticmethod
    def getcurrentactivity() -> GetCurrentActivity:
        """Get current activity."""
        return GetCurrentActivity()

    @staticmethod
    def getdeviceorientationandroid() -> GetDeviceOrientationAndroid:
        """Get current orientation."""
        return GetDeviceOrientationAndroid()

    @staticmethod
    def getnetworkconnectioncellulardata() -> GetNetworkConnectionCellularData:
        """Is Cellular Data enabled?."""
        return GetNetworkConnectionCellularData()

    @staticmethod
    def getnetworkconnectionflightmode() -> GetNetworkConnectionFlightMode:
        """Is Airplane Mode enabled?."""
        return GetNetworkConnectionFlightMode()

    @staticmethod
    def getnetworkconnectionwifistate() -> GetNetworkConnectionWiFiState:
        """Is WiFi enabled?."""
        return GetNetworkConnectionWiFiState()

    @staticmethod
    def getpackagename() -> GetPackageName:
        """Get current package name.

        Returns the current package name.
        """
        return GetPackageName()

    @staticmethod
    def hidekeyboardandroid() -> HideKeyboardAndroid:
        """Hide keyboard."""
        return HideKeyboardAndroid()

    @staticmethod
    def installapp(path: str) -> InstallApp:
        """Install {{path}}.

        Install provided APK onto the device.
        """
        return InstallApp(path)

    @staticmethod
    def isappinstalled(packageName: str) -> IsAppInstalled:
        """Is {{packageName}} installed?.

        Checks if the given application is installed on the device.
        """
        return IsAppInstalled(packageName)

    @staticmethod
    def iskeyboardvisible() -> IsKeyboardVisible:
        """Checks if keyboard is Visible."""
        return IsKeyboardVisible()

    @staticmethod
    def opennotifications() -> OpenNotifications:
        """Open notifications."""
        return OpenNotifications()

    @staticmethod
    def pangesturesandroid(coordinates: str) -> PanGesturesAndroid:
        """Trace the movement of coordinates around the screen, and apply that movement to your content."""
        return PanGesturesAndroid(coordinates)

    @staticmethod
    def pullfile(remote: str, local: str) -> PullFile:
        """Pull {{remote}} to {{local}}.

        Pull a file from an Android device to the local machine.
        """
        return PullFile(remote, local)

    @staticmethod
    def pushfile(remotePath: str, localPath: str) -> PushFile:
        """Save file from {{localPath}} in {{remotePath}}."""
        return PushFile(remotePath, localPath)

    @staticmethod
    def removeapp(packageName: str) -> RemoveApp:
        """Uninstall {{packageName}}.

        Uninstall the given package from the Android device.
        """
        return RemoveApp(packageName)

    @staticmethod
    def setanimations(animator_duration_scale: float, transition_animation_scale: float, window_animation_scale: float) -> SetAnimations:
        """Set animations."""
        return SetAnimations(animator_duration_scale, transition_animation_scale, window_animation_scale)

    @staticmethod
    def setnetworkconnectioncellulardata(expectedState: str) -> SetNetworkConnectionCellularData:
        """Set the Cellular Data {{expectedState}}."""
        return SetNetworkConnectionCellularData(expectedState)

    @staticmethod
    def setnetworkconnectionflightmode(expectedState: str) -> SetNetworkConnectionFlightMode:
        """Set the Airplane Mode {{expectedState}}."""
        return SetNetworkConnectionFlightMode(expectedState)

    @staticmethod
    def setnetworkconnectionsettings(connectionSetting: str) -> SetNetworkConnectionSettings:
        """Set network state - {{connectionSetting}}."""
        return SetNetworkConnectionSettings(connectionSetting)

    @staticmethod
    def setnetworkconnectionwifistate(expectedState: str) -> SetNetworkConnectionWiFiState:
        """Set the WiFi {{expectedState}}."""
        return SetNetworkConnectionWiFiState(expectedState)

    @staticmethod
    def simulatefingerprint(indexOfFinger: str) -> SimulateFingerPrint:
        """Simulate fingerprint {{indexOfFinger}}."""
        return SimulateFingerPrint(indexOfFinger)

    @staticmethod
    def togglelocationservices() -> ToggleLocationServices:
        """Toggle location services."""
        return ToggleLocationServices()

    @staticmethod
    def doubletaponelementios() -> DoubleTapOnElementIOS:
        """Double tap on {{element}}."""
        return DoubleTapOnElementIOS()

    @staticmethod
    def draganddropelementbyoffsetios(xOffset: int, yOffset: int) -> DragAndDropElementByOffsetIOS:
        """Drag {{element}} by offset {{xOffset}},{{yOffset}} and drop."""
        return DragAndDropElementByOffsetIOS(xOffset, yOffset)

    @staticmethod
    def getelementsizeios() -> GetElementSizeIOS:
        """Get Element Size, Height and Width."""
        return GetElementSizeIOS()

    @staticmethod
    def pinchelementios(scale: str) -> PinchElementIOS:
        """Pinch on {{element}}."""
        return PinchElementIOS(scale)

    @staticmethod
    def zoomtoelementios(scale: str, velocity: str) -> ZoomToElementIOS:
        """Zoom on {{element}}."""
        return ZoomToElementIOS(scale, velocity)

    @staticmethod
    def flickgestureios(direction: str) -> FlickGestureIOS:
        """Make a Flick gesture {{direction}}."""
        return FlickGestureIOS(direction)

    @staticmethod
    def getdeviceorientationios() -> GetDeviceOrientationIOS:
        """Get current orientation."""
        return GetDeviceOrientationIOS()

    @staticmethod
    def hidekeyboardios() -> HideKeyboardIOS:
        """Hide keyboard."""
        return HideKeyboardIOS()

    @staticmethod
    def pangesturesios(coordinates: str) -> PanGesturesIOS:
        """Trace the movement of coordinates around the screen, and apply that movement to your content."""
        return PanGesturesIOS(coordinates)

    @staticmethod
    def shake() -> Shake:
        """Make a Shake gesture."""
        return Shake()

    @staticmethod
    def simulatetouchid(failedOrPassedTouch: str) -> SimulateTouchID:
        """Simulate TouchID to {{failedOrPassedTouch}}."""
        return SimulateTouchID(failedOrPassedTouch)

    @staticmethod
    def typetextkeyboardios(input: str) -> TypeTextKeyboardIOS:
        """Type {{input}} using keyboard.

        Use iOS keyboard to type text.
        """
        return TypeTextKeyboardIOS(input)
