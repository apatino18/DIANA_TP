"""This module contains the PanGesturesAndroid proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class PanGesturesAndroid(ActionProxy):
    def __init__(self, coordinates: str):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.android.PanGesturesAndroid"
        )
        self.coordinates = coordinates
