"""This module contains the SetAnimations proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class SetAnimations(ActionProxy):
    def __init__(self, animator_duration_scale: float, transition_animation_scale: float, window_animation_scale: float):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.android.SetAnimations"
        )
        self.animator_duration_scale = animator_duration_scale
        self.transition_animation_scale = transition_animation_scale
        self.window_animation_scale = window_animation_scale
