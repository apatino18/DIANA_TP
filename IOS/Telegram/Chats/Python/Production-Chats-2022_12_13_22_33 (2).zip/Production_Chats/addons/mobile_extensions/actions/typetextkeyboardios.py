"""This module contains the TypeTextKeyboardIOS proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class TypeTextKeyboardIOS(ActionProxy):
    def __init__(self, input: str):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="Pc5arX-ClUCFkcuhm-r25A",
            classname="io.testproject.addons.mobile.ios.TypeTextKeyboardIOS"
        )
        self.input = input
