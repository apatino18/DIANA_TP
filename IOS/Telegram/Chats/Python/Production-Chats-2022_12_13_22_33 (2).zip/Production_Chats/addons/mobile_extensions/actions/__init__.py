"""This package contains all the addon proxy's actions."""
from .checkifscreenislocked import CheckIfScreenIsLocked
from .clickkeyboardsearch import ClickKeyBoardSearch
from .doubletaponelementandroid import DoubleTapOnElementAndroid
from .draganddropelementbyoffsetandroid import DragAndDropElementByOffsetAndroid
from .getattributevalue import GetAttributeValue
from .getelementsizeandroid import GetElementSizeAndroid
from .pinchelementandroid import PinchElementAndroid
from .sendkeyswithadb import SendKeysWithADB
from .zoomtoelementandroid import ZoomToElementAndroid
from .flickgestureandroid import FlickGestureAndroid
from .getcurrentactivity import GetCurrentActivity
from .getdeviceorientationandroid import GetDeviceOrientationAndroid
from .getnetworkconnectioncellulardata import GetNetworkConnectionCellularData
from .getnetworkconnectionflightmode import GetNetworkConnectionFlightMode
from .getnetworkconnectionwifistate import GetNetworkConnectionWiFiState
from .getpackagename import GetPackageName
from .hidekeyboardandroid import HideKeyboardAndroid
from .installapp import InstallApp
from .isappinstalled import IsAppInstalled
from .iskeyboardvisible import IsKeyboardVisible
from .opennotifications import OpenNotifications
from .pangesturesandroid import PanGesturesAndroid
from .pullfile import PullFile
from .pushfile import PushFile
from .removeapp import RemoveApp
from .setanimations import SetAnimations
from .setnetworkconnectioncellulardata import SetNetworkConnectionCellularData
from .setnetworkconnectionflightmode import SetNetworkConnectionFlightMode
from .setnetworkconnectionsettings import SetNetworkConnectionSettings
from .setnetworkconnectionwifistate import SetNetworkConnectionWiFiState
from .simulatefingerprint import SimulateFingerPrint
from .togglelocationservices import ToggleLocationServices
from .doubletaponelementios import DoubleTapOnElementIOS
from .draganddropelementbyoffsetios import DragAndDropElementByOffsetIOS
from .getelementsizeios import GetElementSizeIOS
from .pinchelementios import PinchElementIOS
from .zoomtoelementios import ZoomToElementIOS
from .flickgestureios import FlickGestureIOS
from .getdeviceorientationios import GetDeviceOrientationIOS
from .hidekeyboardios import HideKeyboardIOS
from .pangesturesios import PanGesturesIOS
from .shake import Shake
from .simulatetouchid import SimulateTouchID
from .typetextkeyboardios import TypeTextKeyboardIOS

__all__ = ["CheckIfScreenIsLocked", "ClickKeyBoardSearch", "DoubleTapOnElementAndroid", "DragAndDropElementByOffsetAndroid", "GetAttributeValue", "GetElementSizeAndroid", "PinchElementAndroid", "SendKeysWithADB", "ZoomToElementAndroid", "FlickGestureAndroid", "GetCurrentActivity", "GetDeviceOrientationAndroid", "GetNetworkConnectionCellularData", "GetNetworkConnectionFlightMode", "GetNetworkConnectionWiFiState", "GetPackageName", "HideKeyboardAndroid", "InstallApp", "IsAppInstalled", "IsKeyboardVisible", "OpenNotifications",
           "PanGesturesAndroid", "PullFile", "PushFile", "RemoveApp", "SetAnimations", "SetNetworkConnectionCellularData", "SetNetworkConnectionFlightMode", "SetNetworkConnectionSettings", "SetNetworkConnectionWiFiState", "SimulateFingerPrint", "ToggleLocationServices", "DoubleTapOnElementIOS", "DragAndDropElementByOffsetIOS", "GetElementSizeIOS", "PinchElementIOS", "ZoomToElementIOS", "FlickGestureIOS", "GetDeviceOrientationIOS", "HideKeyboardIOS", "PanGesturesIOS", "Shake", "SimulateTouchID", "TypeTextKeyboardIOS"]
