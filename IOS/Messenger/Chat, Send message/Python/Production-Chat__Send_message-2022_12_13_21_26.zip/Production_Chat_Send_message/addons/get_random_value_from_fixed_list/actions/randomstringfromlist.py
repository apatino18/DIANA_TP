"""This module contains the RandomStringFromList proxy action class."""
from src.testproject.classes import ProxyDescriptor
from src.testproject.sdk.addons import ActionProxy


class RandomStringFromList(ActionProxy):
    def __init__(self, list: str):
        super().__init__()
        self.proxydescriptor = ProxyDescriptor(
            guid="uL4ptjq1h0O1oIdQkkqlyg",
            classname="RandomStringFromList"
        )
        self.list = list
        self.randomResult = None
