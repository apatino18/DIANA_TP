package io.testproject.addon;

import io.testproject.sdk.internal.addons.ActionProxy;
import io.testproject.sdk.internal.addons.ProxyDescriptor;
import java.lang.String;

/**
 * Proxy for Swipe and Find Element Addon */
public class SwipeandFindElement {
  /**
   * Factory method for HorizontalSwipeAndroid */
  public static HorizontalSwipeAndroid getHorizontalSwipeAndroid() {
    return new HorizontalSwipeAndroid();
  }

  /**
   * Factory method for HorizontalSwipeAndroid
   * @param swipeDirection Swipe finger movement direction (Right/Left)
   * @param rightMarginPercent Margin from the right side of screen in percents
   * @param leftMarginPercent Margin from the left side of screen in percents
   * @param maxSwipes Maximum swipes to perform
   * @param timeoutMilliseconds Timeout in milliseconds (For all swipes to occur) */
  public static HorizontalSwipeAndroid horizontalSwipeAndroid(String swipeDirection,
      int rightMarginPercent, int leftMarginPercent, int maxSwipes, int timeoutMilliseconds) {
    return new HorizontalSwipeAndroid(swipeDirection,rightMarginPercent,leftMarginPercent,maxSwipes,timeoutMilliseconds);
  }

  /**
   * Factory method for HorizontalSwipeWithTextAndroid */
  public static HorizontalSwipeWithTextAndroid getHorizontalSwipeWithTextAndroid() {
    return new HorizontalSwipeWithTextAndroid();
  }

  /**
   * Factory method for HorizontalSwipeWithTextAndroid
   * @param text Element's text
   * @param swipeDirection Swipe finger movement direction (Right/Left)
   * @param rightMarginPercent Margin from the right side of screen in percents
   * @param leftMarginPercent Margin from the left side of screen in percents
   * @param maxSwipes Maximum swipes to perform
   * @param timeoutMilliseconds Timeout in milliseconds (For all swipes to occur) */
  public static HorizontalSwipeWithTextAndroid horizontalSwipeWithTextAndroid(String text,
      String swipeDirection, int rightMarginPercent, int leftMarginPercent, int maxSwipes,
      int timeoutMilliseconds) {
    return new HorizontalSwipeWithTextAndroid(text,swipeDirection,rightMarginPercent,leftMarginPercent,maxSwipes,timeoutMilliseconds);
  }

  /**
   * Factory method for VerticalSwipeAndroid */
  public static VerticalSwipeAndroid getVerticalSwipeAndroid() {
    return new VerticalSwipeAndroid();
  }

  /**
   * Factory method for VerticalSwipeAndroid
   * @param swipeDirection Swipe finger movement direction (Up/Down)
   * @param bottomMarginPercent Margin from bottom of the screen in percents (Default 70)
   * @param topMarginPercent Margin from top of the screen in percents (Default 30)
   * @param maxSwipes Maximum swipes to perform (Default 20)
   * @param timeoutMilliseconds Timeout in milliseconds (For all swipes to occur, default 15000) */
  public static VerticalSwipeAndroid verticalSwipeAndroid(String swipeDirection,
      int bottomMarginPercent, int topMarginPercent, int maxSwipes, int timeoutMilliseconds) {
    return new VerticalSwipeAndroid(swipeDirection,bottomMarginPercent,topMarginPercent,maxSwipes,timeoutMilliseconds);
  }

  /**
   * Factory method for HorizontalSwipeIOS */
  public static HorizontalSwipeIOS getHorizontalSwipeIOS() {
    return new HorizontalSwipeIOS();
  }

  /**
   * Factory method for HorizontalSwipeIOS
   * @param swipeDirection Swipe finger movement direction (Right/Left)
   * @param rightMarginPercent Margin from the right side of screen in percents
   * @param leftMarginPercent Margin from the left side of screen in percents
   * @param maxSwipes Maximum swipes to perform
   * @param timeoutMilliseconds Timeout in milliseconds (For all swipes to occur) */
  public static HorizontalSwipeIOS horizontalSwipeIOS(String swipeDirection, int rightMarginPercent,
      int leftMarginPercent, int maxSwipes, int timeoutMilliseconds) {
    return new HorizontalSwipeIOS(swipeDirection,rightMarginPercent,leftMarginPercent,maxSwipes,timeoutMilliseconds);
  }

  /**
   * Factory method for HorizontalSwipeWithTextIOS */
  public static HorizontalSwipeWithTextIOS getHorizontalSwipeWithTextIOS() {
    return new HorizontalSwipeWithTextIOS();
  }

  /**
   * Factory method for HorizontalSwipeWithTextIOS
   * @param text Element's text
   * @param swipeDirection Swipe finger movement direction (Right/Left)
   * @param rightMarginPercent Margin from the right side of screen in percents
   * @param leftMarginPercent Margin from the left side of screen in percents
   * @param maxSwipes Maximum swipes to perform
   * @param timeoutMilliseconds Timeout in milliseconds (For all swipes to occur) */
  public static HorizontalSwipeWithTextIOS horizontalSwipeWithTextIOS(String text,
      String swipeDirection, int rightMarginPercent, int leftMarginPercent, int maxSwipes,
      int timeoutMilliseconds) {
    return new HorizontalSwipeWithTextIOS(text,swipeDirection,rightMarginPercent,leftMarginPercent,maxSwipes,timeoutMilliseconds);
  }

  /**
   * Factory method for VerticalSwipeIOS */
  public static VerticalSwipeIOS getVerticalSwipeIOS() {
    return new VerticalSwipeIOS();
  }

  /**
   * Factory method for VerticalSwipeIOS
   * @param swipeDirection Swipe finger movement direction (Up/Down)
   * @param bottomMarginPercent Margin from bottom of the screen in percents (Default 70)
   * @param topMarginPercent Margin from top of the screen in percents (Default 30)
   * @param maxSwipes Maximum swipes to perform (Default 20)
   * @param timeoutMilliseconds Timeout in milliseconds (For all swipes to occur, default 15000) */
  public static VerticalSwipeIOS verticalSwipeIOS(String swipeDirection, int bottomMarginPercent,
      int topMarginPercent, int maxSwipes, int timeoutMilliseconds) {
    return new VerticalSwipeIOS(swipeDirection,bottomMarginPercent,topMarginPercent,maxSwipes,timeoutMilliseconds);
  }

  /**
   * Factory method for CoordinateSwipeToElement */
  public static CoordinateSwipeToElement getIoTestprojectAddonsMobileElementfinderCoordinateSwipesCoordinateAndroidCoordinateSwipeToElement() {
    return new CoordinateSwipeToElement();
  }

  /**
   * Factory method for CoordinateSwipeToElement
   * @param startXMargin Start X pixel margin (between 0-100% from top left to right of screen)
   * @param startYMargin Start Y pixel margin (between 0-100% from top left to bottom of screen)
   * @param endXMargin End X pixel margin (between 0-100% from top left to right of screen)
   * @param endYMargin End Y pixel margin (between 0-100% from top left to bottom of screen)
   * @param amountOfSwipes Maximum amount of swipes (default: 20) */
  public static CoordinateSwipeToElement ioTestprojectAddonsMobileElementfinderCoordinateSwipesCoordinateAndroidCoordinateSwipeToElement(int startXMargin,
      int startYMargin, int endXMargin, int endYMargin, int amountOfSwipes) {
    return new CoordinateSwipeToElement(startXMargin,startYMargin,endXMargin,endYMargin,amountOfSwipes);
  }

  /**
   * Factory method for CoordinateSwipeToElement */
  public static CoordinateSwipeToElement getIoTestprojectAddonsMobileElementfinderCoordinateSwipesCoordinateIOSCoordinateSwipeToElement() {
    return new CoordinateSwipeToElement();
  }

  /**
   * Factory method for CoordinateSwipeToElement
   * @param startXMargin Start X pixel margin (between 0-100% from top left to right of screen)
   * @param startYMargin Start Y pixel margin (between 0-100% from top left to bottom of screen)
   * @param endXMargin End X pixel margin (between 0-100% from top left to right of screen)
   * @param endYMargin End Y pixel margin (between 0-100% from top left to bottom of screen)
   * @param amountOfSwipes Maximum amount of swipes (default: 20) */
  public static CoordinateSwipeToElement ioTestprojectAddonsMobileElementfinderCoordinateSwipesCoordinateIOSCoordinateSwipeToElement(int startXMargin,
      int startYMargin, int endXMargin, int endYMargin, int amountOfSwipes) {
    return new CoordinateSwipeToElement(startXMargin,startYMargin,endXMargin,endYMargin,amountOfSwipes);
  }

  /**
   * Factory method for SwipeUntilElementAndroidHorizontal */
  public static SwipeUntilElementAndroidHorizontal getSwipeUntilElementAndroidHorizontal() {
    return new SwipeUntilElementAndroidHorizontal();
  }

  /**
   * Factory method for SwipeUntilElementAndroidHorizontal
   * @param direction LEFT to move screen left, RIGHT to move screen right
   * @param amountOfSwipes Maximum amount of swipes (default: 20) */
  public static SwipeUntilElementAndroidHorizontal swipeUntilElementAndroidHorizontal(String direction,
      int amountOfSwipes) {
    return new SwipeUntilElementAndroidHorizontal(direction,amountOfSwipes);
  }

  /**
   * Factory method for SwipeUntilElementAndroidVertical */
  public static SwipeUntilElementAndroidVertical getSwipeUntilElementAndroidVertical() {
    return new SwipeUntilElementAndroidVertical();
  }

  /**
   * Factory method for SwipeUntilElementAndroidVertical
   * @param direction UP to move screen up, DOWN to move screen down
   * @param amountOfSwipes Maximum amount of swipes (default: 20) */
  public static SwipeUntilElementAndroidVertical swipeUntilElementAndroidVertical(String direction,
      int amountOfSwipes) {
    return new SwipeUntilElementAndroidVertical(direction,amountOfSwipes);
  }

  /**
   * Factory method for SwipeUntilElementIOSHorizontal */
  public static SwipeUntilElementIOSHorizontal getSwipeUntilElementIOSHorizontal() {
    return new SwipeUntilElementIOSHorizontal();
  }

  /**
   * Factory method for SwipeUntilElementIOSHorizontal
   * @param direction LEFT to move screen left, RIGHT to move screen right
   * @param amountOfSwipes Maximum amount of swipes (default: 20) */
  public static SwipeUntilElementIOSHorizontal swipeUntilElementIOSHorizontal(String direction,
      int amountOfSwipes) {
    return new SwipeUntilElementIOSHorizontal(direction,amountOfSwipes);
  }

  /**
   * Factory method for SwipeUntilElementIOSVertical */
  public static SwipeUntilElementIOSVertical getSwipeUntilElementIOSVertical() {
    return new SwipeUntilElementIOSVertical();
  }

  /**
   * Factory method for SwipeUntilElementIOSVertical
   * @param direction UP to move screen up, DOWN to move screen down
   * @param amountOfSwipes Maximum amount of swipes (default: 20) */
  public static SwipeUntilElementIOSVertical swipeUntilElementIOSVertical(String direction,
      int amountOfSwipes) {
    return new SwipeUntilElementIOSVertical(direction,amountOfSwipes);
  }

  /**
   * Extended Swipe to Element (Left/Right). null */
  public static class HorizontalSwipeAndroid extends ActionProxy {
    /**
     * Swipe finger movement direction (Right/Left) (INPUT) */
    public String swipeDirection;

    /**
     * Margin from the right side of screen in percents (INPUT) */
    public int rightMarginPercent;

    /**
     * Margin from the left side of screen in percents (INPUT) */
    public int leftMarginPercent;

    /**
     * Maximum swipes to perform (INPUT) */
    public int maxSwipes;

    /**
     * Timeout in milliseconds (For all swipes to occur) (INPUT) */
    public int timeoutMilliseconds;

    public HorizontalSwipeAndroid() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.Actions.Android.HorizontalSwipeAndroid"));
    }

    public HorizontalSwipeAndroid(String swipeDirection, int rightMarginPercent,
        int leftMarginPercent, int maxSwipes, int timeoutMilliseconds) {
      this();
      this.swipeDirection = swipeDirection;
      this.rightMarginPercent = rightMarginPercent;
      this.leftMarginPercent = leftMarginPercent;
      this.maxSwipes = maxSwipes;
      this.timeoutMilliseconds = timeoutMilliseconds;
    }
  }

  /**
   * Extended Swipe to Element by Text (Left/Right). null */
  public static class HorizontalSwipeWithTextAndroid extends ActionProxy {
    /**
     * Element's text (INPUT) */
    public String text;

    /**
     * Swipe finger movement direction (Right/Left) (INPUT) */
    public String swipeDirection;

    /**
     * Margin from the right side of screen in percents (INPUT) */
    public int rightMarginPercent;

    /**
     * Margin from the left side of screen in percents (INPUT) */
    public int leftMarginPercent;

    /**
     * Maximum swipes to perform (INPUT) */
    public int maxSwipes;

    /**
     * Timeout in milliseconds (For all swipes to occur) (INPUT) */
    public int timeoutMilliseconds;

    public HorizontalSwipeWithTextAndroid() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.Actions.Android.HorizontalSwipeWithTextAndroid"));
    }

    public HorizontalSwipeWithTextAndroid(String text, String swipeDirection,
        int rightMarginPercent, int leftMarginPercent, int maxSwipes, int timeoutMilliseconds) {
      this();
      this.text = text;
      this.swipeDirection = swipeDirection;
      this.rightMarginPercent = rightMarginPercent;
      this.leftMarginPercent = leftMarginPercent;
      this.maxSwipes = maxSwipes;
      this.timeoutMilliseconds = timeoutMilliseconds;
    }
  }

  /**
   * Extended Swipe to Element (Up/Down). null */
  public static class VerticalSwipeAndroid extends ActionProxy {
    /**
     * Swipe finger movement direction (Up/Down) (INPUT) */
    public String swipeDirection;

    /**
     * Margin from bottom of the screen in percents (Default 70) (INPUT) */
    public int bottomMarginPercent;

    /**
     * Margin from top of the screen in percents (Default 30) (INPUT) */
    public int topMarginPercent;

    /**
     * Maximum swipes to perform (Default 20) (INPUT) */
    public int maxSwipes;

    /**
     * Timeout in milliseconds (For all swipes to occur, default 15000) (INPUT) */
    public int timeoutMilliseconds;

    public VerticalSwipeAndroid() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.Actions.Android.VerticalSwipeAndroid"));
    }

    public VerticalSwipeAndroid(String swipeDirection, int bottomMarginPercent,
        int topMarginPercent, int maxSwipes, int timeoutMilliseconds) {
      this();
      this.swipeDirection = swipeDirection;
      this.bottomMarginPercent = bottomMarginPercent;
      this.topMarginPercent = topMarginPercent;
      this.maxSwipes = maxSwipes;
      this.timeoutMilliseconds = timeoutMilliseconds;
    }
  }

  /**
   * Extended Swipe to Element (Left/Right). null */
  public static class HorizontalSwipeIOS extends ActionProxy {
    /**
     * Swipe finger movement direction (Right/Left) (INPUT) */
    public String swipeDirection;

    /**
     * Margin from the right side of screen in percents (INPUT) */
    public int rightMarginPercent;

    /**
     * Margin from the left side of screen in percents (INPUT) */
    public int leftMarginPercent;

    /**
     * Maximum swipes to perform (INPUT) */
    public int maxSwipes;

    /**
     * Timeout in milliseconds (For all swipes to occur) (INPUT) */
    public int timeoutMilliseconds;

    public HorizontalSwipeIOS() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.Actions.iOS.HorizontalSwipeIOS"));
    }

    public HorizontalSwipeIOS(String swipeDirection, int rightMarginPercent, int leftMarginPercent,
        int maxSwipes, int timeoutMilliseconds) {
      this();
      this.swipeDirection = swipeDirection;
      this.rightMarginPercent = rightMarginPercent;
      this.leftMarginPercent = leftMarginPercent;
      this.maxSwipes = maxSwipes;
      this.timeoutMilliseconds = timeoutMilliseconds;
    }
  }

  /**
   * Extended Swipe to Element by Text (Left/Right). null */
  public static class HorizontalSwipeWithTextIOS extends ActionProxy {
    /**
     * Element's text (INPUT) */
    public String text;

    /**
     * Swipe finger movement direction (Right/Left) (INPUT) */
    public String swipeDirection;

    /**
     * Margin from the right side of screen in percents (INPUT) */
    public int rightMarginPercent;

    /**
     * Margin from the left side of screen in percents (INPUT) */
    public int leftMarginPercent;

    /**
     * Maximum swipes to perform (INPUT) */
    public int maxSwipes;

    /**
     * Timeout in milliseconds (For all swipes to occur) (INPUT) */
    public int timeoutMilliseconds;

    public HorizontalSwipeWithTextIOS() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.Actions.iOS.HorizontalSwipeWithTextIOS"));
    }

    public HorizontalSwipeWithTextIOS(String text, String swipeDirection, int rightMarginPercent,
        int leftMarginPercent, int maxSwipes, int timeoutMilliseconds) {
      this();
      this.text = text;
      this.swipeDirection = swipeDirection;
      this.rightMarginPercent = rightMarginPercent;
      this.leftMarginPercent = leftMarginPercent;
      this.maxSwipes = maxSwipes;
      this.timeoutMilliseconds = timeoutMilliseconds;
    }
  }

  /**
   * Extended Swipe to Element (Up/Down). null */
  public static class VerticalSwipeIOS extends ActionProxy {
    /**
     * Swipe finger movement direction (Up/Down) (INPUT) */
    public String swipeDirection;

    /**
     * Margin from bottom of the screen in percents (Default 70) (INPUT) */
    public int bottomMarginPercent;

    /**
     * Margin from top of the screen in percents (Default 30) (INPUT) */
    public int topMarginPercent;

    /**
     * Maximum swipes to perform (Default 20) (INPUT) */
    public int maxSwipes;

    /**
     * Timeout in milliseconds (For all swipes to occur, default 15000) (INPUT) */
    public int timeoutMilliseconds;

    public VerticalSwipeIOS() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.Actions.iOS.VerticalSwipeIOS"));
    }

    public VerticalSwipeIOS(String swipeDirection, int bottomMarginPercent, int topMarginPercent,
        int maxSwipes, int timeoutMilliseconds) {
      this();
      this.swipeDirection = swipeDirection;
      this.bottomMarginPercent = bottomMarginPercent;
      this.topMarginPercent = topMarginPercent;
      this.maxSwipes = maxSwipes;
      this.timeoutMilliseconds = timeoutMilliseconds;
    }
  }

  /**
   * Swipe to Element Using Coordinates. Swipe between coordinates until element is displayed */
  public static class CoordinateSwipeToElement extends ActionProxy {
    /**
     * Start X pixel margin (between 0-100% from top left to right of screen) (INPUT) */
    public int startXMargin;

    /**
     * Start Y pixel margin (between 0-100% from top left to bottom of screen) (INPUT) */
    public int startYMargin;

    /**
     * End X pixel margin (between 0-100% from top left to right of screen) (INPUT) */
    public int endXMargin;

    /**
     * End Y pixel margin (between 0-100% from top left to bottom of screen) (INPUT) */
    public int endYMargin;

    /**
     * Maximum amount of swipes (default: 20) (INPUT) */
    public int amountOfSwipes;

    public CoordinateSwipeToElement() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.CoordinateSwipes.CoordinateAndroid.CoordinateSwipeToElement"));
    }

    public CoordinateSwipeToElement(int startXMargin, int startYMargin, int endXMargin,
        int endYMargin, int amountOfSwipes) {
      this();
      this.startXMargin = startXMargin;
      this.startYMargin = startYMargin;
      this.endXMargin = endXMargin;
      this.endYMargin = endYMargin;
      this.amountOfSwipes = amountOfSwipes;
    }
  }

  /**
   * Swipe to Element Using Coordinates. Swipe between coordinates until element is displayed */
  public static class CoordinateSwipeToElement extends ActionProxy {
    /**
     * Start X pixel margin (between 0-100% from top left to right of screen) (INPUT) */
    public int startXMargin;

    /**
     * Start Y pixel margin (between 0-100% from top left to bottom of screen) (INPUT) */
    public int startYMargin;

    /**
     * End X pixel margin (between 0-100% from top left to right of screen) (INPUT) */
    public int endXMargin;

    /**
     * End Y pixel margin (between 0-100% from top left to bottom of screen) (INPUT) */
    public int endYMargin;

    /**
     * Maximum amount of swipes (default: 20) (INPUT) */
    public int amountOfSwipes;

    public CoordinateSwipeToElement() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.CoordinateSwipes.CoordinateIOS.CoordinateSwipeToElement"));
    }

    public CoordinateSwipeToElement(int startXMargin, int startYMargin, int endXMargin,
        int endYMargin, int amountOfSwipes) {
      this();
      this.startXMargin = startXMargin;
      this.startYMargin = startYMargin;
      this.endXMargin = endXMargin;
      this.endYMargin = endYMargin;
      this.amountOfSwipes = amountOfSwipes;
    }
  }

  /**
   * Swipe to Element (Left/Right). Swipes in given direction until element is displayed */
  public static class SwipeUntilElementAndroidHorizontal extends ActionProxy {
    /**
     * LEFT to move screen left, RIGHT to move screen right (INPUT) */
    public String direction;

    /**
     * Maximum amount of swipes (default: 20) (INPUT) */
    public int amountOfSwipes;

    public SwipeUntilElementAndroidHorizontal() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.SimpleSwipes.SimpleAndroid.SwipeUntilElementAndroidHorizontal"));
    }

    public SwipeUntilElementAndroidHorizontal(String direction, int amountOfSwipes) {
      this();
      this.direction = direction;
      this.amountOfSwipes = amountOfSwipes;
    }
  }

  /**
   * Swipe to Element (Up/Down). Swipes in given direction until element is displayed */
  public static class SwipeUntilElementAndroidVertical extends ActionProxy {
    /**
     * UP to move screen up, DOWN to move screen down (INPUT) */
    public String direction;

    /**
     * Maximum amount of swipes (default: 20) (INPUT) */
    public int amountOfSwipes;

    public SwipeUntilElementAndroidVertical() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.SimpleSwipes.SimpleAndroid.SwipeUntilElementAndroidVertical"));
    }

    public SwipeUntilElementAndroidVertical(String direction, int amountOfSwipes) {
      this();
      this.direction = direction;
      this.amountOfSwipes = amountOfSwipes;
    }
  }

  /**
   * Swipe to Element (Left/Right). Swipes in given direction until element is displayed */
  public static class SwipeUntilElementIOSHorizontal extends ActionProxy {
    /**
     * LEFT to move screen left, RIGHT to move screen right (INPUT) */
    public String direction;

    /**
     * Maximum amount of swipes (default: 20) (INPUT) */
    public int amountOfSwipes;

    public SwipeUntilElementIOSHorizontal() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.SimpleSwipes.SimpleIOS.SwipeUntilElementIOSHorizontal"));
    }

    public SwipeUntilElementIOSHorizontal(String direction, int amountOfSwipes) {
      this();
      this.direction = direction;
      this.amountOfSwipes = amountOfSwipes;
    }
  }

  /**
   * Swipe to Element (Up/Down). Swipes in given direction until element is displayed */
  public static class SwipeUntilElementIOSVertical extends ActionProxy {
    /**
     * UP to move screen up, DOWN to move screen down (INPUT) */
    public String direction;

    /**
     * Maximum amount of swipes (default: 20) (INPUT) */
    public int amountOfSwipes;

    public SwipeUntilElementIOSVertical() {
      this.setDescriptor(new ProxyDescriptor("3nqfr8Djt0KB-sz43jU-0g", "io.testproject.addons.mobile.elementfinder.SimpleSwipes.SimpleIOS.SwipeUntilElementIOSVertical"));
    }

    public SwipeUntilElementIOSVertical(String direction, int amountOfSwipes) {
      this();
      this.direction = direction;
      this.amountOfSwipes = amountOfSwipes;
    }
  }
}
